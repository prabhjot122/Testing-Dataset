# Drafting Audit- 30 October

I have completed my draft audit tested on 3  document type of drafts. Firstly I tested with a dissolution of marriage by degree of divorce on grounds of cruelty. Its under the Section 13 of Hindu Marriage Act, 1955. Next I also created a Section 138 dishonor of cheque legal notice draft, and the third draft I tested was the FIR complaint under Section 173 of BNSS for theft of mobile phone. 

## REMARKS:

Now Firstly the drafts are neither accurate, nor its formatted correctly. The drafts which are produced are very basic and can never be ready for court filing.

Each of the sections are inaccurate, all subheadings entered its producing new facts and inventing facts beyond it which i did not provide in the prompt. Next it also generates some API key displayed in the draft with date and time which should not be present. 

Even I provide the prompt with so many facts, information and also the section, still it could not generate the required draft properly.

Main thing which I frequently notice is that may be because of the subheadings and the draft outline headings, and from there it generates this draft. So basically there the problem lies. 

For example, after the prompt is submitted, it asks for specific questions prior generation and it also asks for the draft outline. I think the problem lies there. The draft outline is the main problem which should be fixed. Whenever the draft outline is given with all the facts, it creates based upon the facts and it creates incorrect drafts which are not court filing ready. We should rectify the draft outline and also the questions which it asks, and also fix the draft generation engine.

I am providing with the drafts produced by the LawVriksh draft engine, and also giving the redlining of the drafts which i created and also the correct version of the drafts for reference. 

The sequence follows as:

1. The draft produced by LawVriksh
2. Redline review of the draft
3. Correct version of the draft

## FIR complaint

[FIR draft.pdf](Drafting%20Audit-%2030%20October/FIR_draft.pdf)

[FIR Redline Review.docx](Drafting%20Audit-%2030%20October/FIR_Redline_Review.docx)

[FIR Corrected Complaint.docx](Drafting%20Audit-%2030%20October/FIR_Corrected_Complaint.docx)

## Divorce petition

[Matrimonial Dispute 1 (lawvriksh).pdf](Drafting%20Audit-%2030%20October/Matrimonial_Dispute_1_(lawvriksh).pdf)

[Redline Matrimonial Dispute.docx](Drafting%20Audit-%2030%20October/Redline_Matrimonial_Dispute.docx)

[Redline Matrimonial Dispute.docx](Drafting%20Audit-%2030%20October/Redline_Matrimonial_Dispute%201.docx)

## Section 138 Legal Notice

[Sec 138 draft.pdf](Drafting%20Audit-%2030%20October/Sec_138_draft.pdf)

[Sec138 Redline Review.docx](Drafting%20Audit-%2030%20October/Sec138_Redline_Review.docx)

[Sec138 Corrected Notice.docx](Drafting%20Audit-%2030%20October/Sec138_Corrected_Notice.docx)

# **Civil Plaint**

[LawVriksh- Civil plaint.pdf](Drafting%20Audit-%2030%20October/LawVriksh-_Civil_plaint.pdf)

[Civil Plaint Redline Review.docx](Drafting%20Audit-%2030%20October/Civil_Plaint_Redline_Review.docx)

[Civil Plaint Corrected.docx](Drafting%20Audit-%2030%20October/Civil_Plaint_Corrected.docx)

# Bail Application

[LawVriksh- Bail.pdf](Drafting%20Audit-%2030%20October/LawVriksh-_Bail.pdf)

[Bail Redline Review.docx](Drafting%20Audit-%2030%20October/Bail_Redline_Review.docx)

[Bail Corrected Application.docx](Drafting%20Audit-%2030%20October/Bail_Corrected_Application.docx)

# **Consumer Complaint**

[LawVriksh- Consumer Complaint.pdf](Drafting%20Audit-%2030%20October/LawVriksh-_Consumer_Complaint.pdf)

[Consumer Complaint Redline Audit.pdf](Drafting%20Audit-%2030%20October/Consumer_Complaint_Redline_Audit.pdf)

[Consumer Complaint Corrected.docx](Drafting%20Audit-%2030%20October/Consumer_Complaint_Corrected.docx)